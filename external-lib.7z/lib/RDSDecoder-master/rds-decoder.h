#include <stdint.h>

const uint8_t RDS_TMC_D2DynamicPersistence[8] = {
    15, 15, 30, 60, 120, 180, 240, 0xFE};
const uint8_t RDS_TMC_D2LongerlastingPersistence[8] = {
    60, 120, 0xFE, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF};
